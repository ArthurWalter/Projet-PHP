<?php
  session_start();
  include("identifiants.php");
?>
<head>  <link rel="stylesheet" href="CSS/php.css"></head>
<body>
  <?php
  print_r($_POST);
  echo'<h1>Ajout termin�</h1>';
  echo'<p>cliquez <a href="menu.php">ici</a> pour revenir en arrière</p>';
  $query = $db->prepare("INSERT INTO NEWS (idtheme,titrenews,datenews,textenews,idredacteur) VALUES(?,?,now(),?,?)") ;
  $query->bindValue(1,$_POST['description'],PDO::PARAM_STR);
  $query->bindValue(2,$_POST['titrenews'],PDO::PARAM_STR);
  $query->bindValue(3,$_POST['texte'],PDO::PARAM_STR);
  $query->bindValue(4,$_SESSION['id'],PDO::PARAM_STR);
  $query->execute();
  $query->CloseCursor();
  ?>
</body>
</html>
