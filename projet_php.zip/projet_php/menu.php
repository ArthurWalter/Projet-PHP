<?php
$titre = "Menu";
session_start();
include("entete.php"); ?>
  <script language="javascript" type="text/javascript">
  function valider(){
    if (confirm("Se déconnecter ?")){
      window.location.href="deconnexion.php"; return true;
    }
    else return false;
  }
  function connexion(){
    window.location.href="connexion.php";
  }
  function inscription(){
    window.location.href="inscription.php";
  }
  function ecriture(){
    window.location.href="ajout_news.php";
  }
  </script>
  <link rel="stylesheet" href="CSS/menu.css"/>
  </head>
<body>
<nav>
    <ul>
      <li id = "logo"></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <?php
        if (isset($_SESSION['id'])){
      echo '<li id = "ecriture" class="ahover"><a onclick="ecriture()">ECRIRE UNE NEWS</a></li>
      <li id = "deconnexion" class="ahover"><a onclick="valider()">DECONNEXION</a></li>';
      echo '<li id = "profil">';
      echo $_SESSION["prenom"] . ' ' . $_SESSION["nom"];
      echo '</li>';}
        else {
      echo '<li id = "connexion" class="ahover"><a onclick="connexion()">CONNEXION</a></li>
      <li id = "inscription" class="ahover"><a onclick="inscription()">INSCRIPTION</a></li>';}
     ?>
    </ul>
  </nav>
<form method="post" action="menu.php" enctype="multipart/form-data">
<select name='tri'>
    <option value='1'> Tri par date
    <option value='2'> Tri par theme
</select>
<p><input type="submit" value="Tri" /></p>
</form>

<?php
include 'identifiants.php';
$requete ="SELECT *,DATE_FORMAT(datenews,'%d-%m-%Y &#224 %H:%i') as date
FROM NEWS,THEME,REDACTEUR
WHERE REDACTEUR.idredacteur=NEWS.idredacteur
AND NEWS.idtheme = THEME.idtheme";

if(isset($_POST['tri'])){
  $tri = ceil($_POST['tri']);
}else{
  $result = $db->query($requete);
}
if($tri==1){
  $result = $db->query($requete." order by datenews desc ");
} else if($tri==2){
  $result = $db->query($requete." order by CAST(NEWS.idtheme as unsigned) asc ");
}

// order by CAST(NEWS.idtheme as unsigned) asc // ou desc// ou  // order by date desc
while ($row=$result->fetch()){
echo"<article class='article_news'>";
echo  $row ['description'] . " - " . $row ['titrenews'] . " - " . $row['date'] . "<br>";
echo  $row ['textenews'] . "<br />";
echo  " écrit par : " .  $row['prenom'] . " " . $row['nom'];
echo"</article><br>";

}
$result ->closeCursor();
?>
</body>
</html>
