<p><form method="post" action="includes/ajout_news.php" enctype="multipart/form-data">
                 <fieldset><legend>Ajout News : </legend>

             <!-- <label for="description">Thème de votre news : </label>
             <select name='description'>

              // include 'identifiants.php';
              // $requete = "Select * for THEME";
              // $result = $db->query($requete);
              //
              // while($row = $result->fetch()){
              //   echo "<option value=$row['idtheme']>". ">" . "$row['description']";
              // }
              // $result ->closeCursor();
        
                 </select> -->

                <select name="description">
                  <option value='1'>Sport
                  <option value='2'>Science
                  <option value='3'>Economie
                  <option value='4'>Politique
                  <option value='5'>Informatique
                </select>
                  <label for="titrenews">* titre de votre News :</label> <input name="titrenews" type="text" id="titrenews"/><br />
                  <p>* texte de votre news : </p>
                  <textarea rows='32' cols='128' name='texte'></textarea><br><br>
                  <p><input type="submit" value="Ajouter une news : " /></p>
                </fieldset>
    </form></p>
