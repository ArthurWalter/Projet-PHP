<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
</head>
<body>
<?php
  define('ERR_IS_CO','Vous ne pouvez pas accéder à cette page si vous n\'êtes pas connecté');
  session_start();
  include("includes/identifiants.php");
  include("entete.php");
  function erreur($err='') {
    $mess=($err!='')? $err:'Une erreur inconnue s\'est produite';
    exit('<p>'.$mess.'</p>
          <p>Cliquez <a href="menu.php">ici</a> pour revenir à la page d\'accueil</p></div></body></html>');
  }
  echo '<h1>Connexion</h1>';
  if ($id!=0)
    erreur(ERR_IS_CO);
  if (!isset($_POST['mail'])) {
    echo '<form method="post" action="connexion.php">
    <fieldset>
    <legend>Connexion</legend>
    <p><label for="mail">Mail :</label><input name="mail" type="text" id="mail" /><br />
    <label for="password">Mot de Passe :</label><input type="password" name="password" id="password" /></p></fieldset>
    <p><input type="submit" value="Connexion" /></p></form></div></body></html>';
  }
  else {
    $message = '';
    if (empty($_POST['mail']) || empty($_POST['password'])) {
      $message = '<p>une erreur s\'est produite pendant votre identification.
                  Vous devez remplir tous les champs</p>
                  <p>Cliquez <a href="connexion.php">ici</a> pour revenir</p>';
    }
    else {
      $query = $db->prepare('SELECT idredacteur, nom, prenom, adressemail, motdepasse FROM REDACTEUR WHERE adressemail = :mail');
      $query->bindValue(':mail',$_POST['mail'],PDO::PARAM_STR);
      $query->execute();
      $data=$query->fetch();
      if ($data['motdepasse'] == $_POST['password']) {
        $_SESSION['id'] = $data['idredacteur'];
        $_SESSION['nom'] = $data['nom'];
        $_SESSION['prenom'] = $data['prenom'];
        $message = '<p>Bienvenue '.$data['prenom'].' '.$data['nom'].', vous êtes maintenant connecté!</p>
                    <P>Cliquez <a href="connexion.php">ici</a> pour revenir à la page d\'accueil</p>';
      }
      else {
        $message = '<p>Une erreur s\'est produite pendant votre identification.<br /> Le mot de passe ou le nom entré n\'est pas correct.</p>
                    <p>Cliquez <a href="menu.php">ici</a> pour revenir à la page d\'accueil</p>';
      }
      $query->CloseCursor();
    }
    echo $message.'</div></body></html>';
  }
?>
