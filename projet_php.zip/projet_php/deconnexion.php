<body>
<?php
$titre = "Deconnexion";
session_start();
session_destroy();
include("entete.php");
if($id==0) erreur(ERR_IS_NOT_CO);
echo '<p>Vous �tes � pr�sent d�connect� <br />
Cliquez <a href="menu.php">ici</a>
pour revenir � la page pr�c�dente.</p>';
echo '</body></html>';
?>