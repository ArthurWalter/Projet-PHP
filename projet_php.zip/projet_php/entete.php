<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/whtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
<head>

  <link rel="stylesheet" href="CSS/php.css">
  <?php
    echo (!empty($titre))?'<title>'.$titre.'</title>':'<title> News </title>';
  ?>
  <meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<?php
  $id=(isset($_SESSION['id']))?(int)$_SESSION['id']:0;
  $nom=(isset($_SESSION['nom']))?$_SESSION['nom']:'';
  $prenom=(isset($_SESSION['prenom']))?$_SESSION['prenom']:'';
  include("./includes/functions.php");
  include("./includes/constants.php");
?>
</head>
<body>
</body>
