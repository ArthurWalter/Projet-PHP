<?php
  session_start();
  $titre = "Inscription";
  include("includes/identifiants.php");
  include("entete.php");
?>
<body>
  <?php
    if ($id!=0)erreur(ERR_IS_NOT_CO);
    if (empty($_POST['nom']) && empty($_POST['prenom'])) {
      echo '<h1>Inscription</h1>';
      echo '<form method="post" action="inscription.php" enctype="multipart/form-data">
            <fieldset><legend>Identifiants</legend>
            <label for="nom">* Nom :</label> <input name="nom" type="text" id="nom" /> <label for="prenom">* Prenom :</label> <input name="prenom" type="text" id="prenom" /><br />
            <label for="password">* Mot de Passe :</label> <input type="password" name="password" id="password" /><br />
            <label for="confirm">* Confirmer le mot de passe :</label> <input type="password" name="confirm" id="confirm" /></fieldset>
            <fieldset><legend>Contact</legend>
            <label for="email">*Votre adresse Mail :</label> <input type="email" name="email" id="email" /><br /></fieldset>
            <p>Les champs précédés d\'un * sont obligatoires</p>
            <p><input type="submit" value="S\'inscrire" /></p></form></div></body></html>';
    }
    else {
      $redacteur_erreur1 = NULL;
      $redacteur_erreur2 = NULL;
      $mdp_erreur = NULL;
      $email_erreur1 = NULL;
      $email_erreur2 = NULL;
      $i = 0;
      $nom = $_POST['nom'];
      $prenom = $_POST['prenom'];
      $password = $_POST['password'];
      $confirm = $_POST['confirm'];
      $email = $_POST['email'];
      $query = $db->prepare('SELECT COUNT(*) AS nbr FROM REDACTEUR WHERE nom = :nom AND prenom = :prenom');
      $query->bindValue(':nom',$nom,PDO::PARAM_STR);
      $query->bindValue(':prenom',$prenom,PDO::PARAM_STR);
      $query->execute();
      $query->CloseCursor();
      if($password != $confirm || empty($confirm) || empty($password)){
        $mdp_erreur = "Votre mot de passe et votre confirmation diffèrent, ou sont vides";
        $i++;
      }
      $query = $db->prepare('SELECT COUNT(*) AS nbr FROM REDACTEUR WHERE adressemail = :email');
      $query->bindValue(':email',$email,PDO::PARAM_STR);
      $query->execute();
      $email_free = ($query->fetchColumn()==0)?1:0;
      $query->CloseCursor();
      if(!$email_free){
        $email_erreur1 = "Votre adresse email est déjà utilisée par un membre";
        $i++;
      }
      if(!preg_match("#^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]{2,}\.[a-z]{2,4}$#",$email) || empty($email)){
        $email_erreur2 = "Votre adresse email n'a pas un format valide";
        $i++;
      }
      if($i == 0){
        echo'<h1>Inscription terminée</h1>';
        echo'<p>Bienvenue '.stripslashes(htmlspecialchars($_POST['prenom'])).' '.stripslashes(htmlspecialchars($_POST['nom'])).' vous êtes maintenant inscrit sur le forum</p>
        <p>cliquez <a href="menu.php">ici</a> pour revenir en arrière</p>';
        $query=$db->prepare('INSERT INTO REDACTEUR (nom,prenom,adressemail,motdepasse) VALUES (:nom,:prenom,:email,:password)');
        $query->bindValue(':nom',$nom,PDO::PARAM_STR);
        $query->bindValue(':prenom',$prenom,PDO::PARAM_STR);
        $query->bindValue(':email',$email,PDO::PARAM_STR);
        $query->bindValue(':password',$password,PDO::PARAM_STR);
        $query->execute();
        $_SESSION['nom'] = $nom;
        $_SESSION['prenom'] = $prenom;
        $_SESSION['id'] = $db->lastInsertId();
        $query->CloseCursor();
      }
      else {
        echo'<h1>Inscription interrompue</h1>';
        echo'<p>Une ou plusieurs erreurs se sont produites pendant l\'inscription</p>';
        echo'<p>'.$i.' erreur(s)</p>';
        echo'<p>'.$mdp_erreur.'</p>';
        echo'<p>'.$email_erreur1.'</p>';
        echo'<p>'.$email_erreur2.'</p>';
        echo'<p>Cliquez <a href="inscription.php">ici</a> pour réessayer.</p>';
      }
    }
  ?>
</body>
</html>
