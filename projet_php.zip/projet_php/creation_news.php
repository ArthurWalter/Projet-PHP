<?php
  session_start();
  $titre = "Ajout News";
  include("includes/identifiants.php");
  include("entete.php");
?>
<body>
  <?php
    if ($id==0)erreur(ERR_IS_NOT_CO);
    if (isset($_SESSION['id'])) {
      echo '<h1>Ajout News</h1>';
      echo '<form method="post" action="creation_news.php" enctype="multipart/form-data">
              <fieldset><legend>Ajout News : </legend>
                <label for="description">Th�me de votre news : </label>
                  <select name="description">
                    <option value='1'>Sport
                    <option value='2'>Science
                    <option value='3'>Economie
                    <option value='4'>Politique
                    <option value='5'>Informatique
                  </select>
                <label for="titrenews">* titre de votre News :</label> <input name="titrenews" type="text" id="titrenews"/><br />
                <p>* texte de votre news : </p>
                  <textarea rows='32' cols='128' name='texte'></textarea><br><br>
                <p><input type="submit" value="Ajouter une news : " /></p>
              </fieldset>
    	    </form></p>';
    }
    else {
      if($i == 0){
        echo'<h1>Ajout termin�</h1>';
  	echo'<p>cliquez <a href="menu.php">ici</a> pour revenir en arrière</p>';
  	$query = $db->prepare("INSERT INTO NEWS (idtheme,titrenews,datenews,textenews,idredacteur) VALUES(?,?,now(),?,?)") ;
  	$query->bindValue(1,$_POST['description'],PDO::PARAM_STR);
  	$query->bindValue(2,$_POST['titrenews'],PDO::PARAM_STR);
  	$query->bindValue(3,$_POST['texte'],PDO::PARAM_STR);
	$query->bindValue(4,$_SESSION['id'],PDO::PARAM_STR);
  	$query->execute();
  	$query->CloseCursor();
      }
      else {
        echo'<h1>Ajout interrompu</h1>';
        echo'<p>Une ou plusieurs erreurs se sont produites pendant l\'inscription</p>';
        echo'<p>'.$i.' erreur(s)</p>';
        echo'<p>'.$erreur.'</p>';
        echo'<p>Cliquez <a href="creation_news.php">ici</a> pour rÃ©essayer.</p>';
      }
    }
  ?>
</body>
</html>
